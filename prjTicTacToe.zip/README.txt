/*****************************************************************
	Project: TicTacToe (Console Game)
	Author: Robert Milan
	Date: 10/25/2021

	Programming Language: VC++ 2019

	Website: somniatus.com
	LinkedIn: https://www.linkedin.com/in/robert-milan-62a37083/
	Facebook: https://www.facebook.com/robert.milan.58
	email: rmilan08@gmail.com


	Description:
		
		A beginners program of TicTacToe which was
	   made as a learning resource to myself and those
	   who wish to download this file.

	   	(A)lways, when learning and using someone elses
          material, be sure to thank them in the credits or
	  about me section of your applications.

******************************************************************/